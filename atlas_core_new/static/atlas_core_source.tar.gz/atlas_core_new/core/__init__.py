"""atlas-core/core - Core modules for Atlas system."""
