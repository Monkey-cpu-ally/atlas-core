"""
atlas_core/core/brain/threat_engine.py

Threat classification (placeholder).
"""


class ThreatEngine:
    def classify(self, text: str) -> str:
        return "low"
