from .registry import load_plugins

__all__ = ["load_plugins"]
