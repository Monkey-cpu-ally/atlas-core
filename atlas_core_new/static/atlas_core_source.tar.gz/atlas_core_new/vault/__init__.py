"""atlas-core/vault - Device schema and configuration."""
