"""
ATLAS Projects Module
Personal projects, specs, designs and ideas integrated into teaching/building system.
Uses LEGO-style instruction model for clear, step-by-step learning.
"""
