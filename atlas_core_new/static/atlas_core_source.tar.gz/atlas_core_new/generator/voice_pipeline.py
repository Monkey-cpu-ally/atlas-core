"""
atlas_core/generator/voice_pipeline.py

Voice content pipeline (placeholder).
"""


class VoicePipeline:
    pass
