"""
atlas_core/generator/text_pipeline.py

Text content pipeline (placeholder).
"""


class TextPipeline:
    pass
